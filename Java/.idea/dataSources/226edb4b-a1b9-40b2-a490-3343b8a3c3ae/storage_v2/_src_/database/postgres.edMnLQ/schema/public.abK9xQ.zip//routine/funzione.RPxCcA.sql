create function funzione(stringa character varying) returns text
    language plpgsql
as
$$
    DECLARE
    parola1 VARCHAR(1000);
    query text := 'SELECT DISTINCT T.CodF FROM f.tagfoto AS T WHERE ';
    count INTEGER := 1;
    numParole INTEGER := (regexp_count(stringa, '@') + 1);
    codF f.tagfoto.CodF%TYPE;
    output text;
    cursor REFCURSOR;

    BEGIN
        FOR i IN 1..numParole LOOP
            parola1 = split_part(stringa, '@', i);
            IF count < numParole THEN
                query:= concat(query, 'Parola = ', '''', parola1 ,'''', 'OR ');
            ELSE
                query:= concat(query,'Parola =', '''', parola1,'''', ';');
            END IF;
            count = count + 1;
            END LOOP;
        RAISE NOTICE 'Query: {%}', query;
        OPEN cursor FOR EXECUTE query;
        count = 0;
        LOOP
            FETCH cursor INTO codF;
            EXIT WHEN NOT FOUND;
            IF count = 0 THEN
                output = codF;
            ELSE
                output = concat(output, ',', codF);
            END IF;
            count = count +1;
        END LOOP;
        CLOSE cursor;

        RAISE NOTICE 'Risultato : {%}', output;
        RETURN output;
    END;
$$;

alter function funzione(varchar) owner to postgres;

