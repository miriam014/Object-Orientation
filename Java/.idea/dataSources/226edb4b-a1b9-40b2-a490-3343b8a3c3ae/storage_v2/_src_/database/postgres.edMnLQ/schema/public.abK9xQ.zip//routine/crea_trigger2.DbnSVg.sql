create function crea_trigger2() returns trigger
    language plpgsql
as
$$
    BEGIN
        DELETE FROM p.Prenotazione AS PRE
        WHERE NEW.Utente = PRE.Utente AND NEW.CodiceBarre = p.esemplare.CodiceBarre;
        RETURN NEW;
    END;
$$;

alter function crea_trigger2() owner to giuliagargiulo;

