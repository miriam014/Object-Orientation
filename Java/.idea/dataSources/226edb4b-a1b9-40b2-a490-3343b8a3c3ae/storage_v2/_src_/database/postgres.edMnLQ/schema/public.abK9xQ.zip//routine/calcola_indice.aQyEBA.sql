create function calcola_indice(orcid_autore integer) returns integer
    language plpgsql
as
$$
    DECLARE
        Hindex integer;
        num_articoli integer;

    BEGIN
        --NUMERO ARTICOLI DI ORCID_autore
            num_articoli =( SELECT COUNT (DOI)
            FROM b.Scrive AS S NATURAL JOIN b.Articolo AS ART
            WHERE S.ORCID = ORCID_autore);
        RAISE NOTICE '%d', num_articoli;


        --CITAZIONI DI UN ARTICOLO DI ORCID_autore
            SELECT S.doi, COUNT(doicitato) as C
            FROM b.Scrive AS S JOIN b.bibliografia AS B ON B.doicitato = S.Doi
            WHERE S.orcid = ORCID_autore
            GROUP BY(S.DOI)
            ORDER BY (c) desc;

    RETURN Hindex;
    END;
$$;

alter function calcola_indice(integer) owner to postgres;

