create function triggeraggiornasaldoportafoglio() returns trigger
    language plpgsql
as
$$
    BEGIN
    UPDATE smu.Portafoglio
        SET Saldo = Saldo + (SELECT T.Importo
                             FROM (smu.Transazione AS T JOIN smu.TransazioniInPortafogli AS TP on T.IdTransazione = TP.IdTransazione)
                                 JOIN smu.Portafoglio AS P on TP.IdPortafoglio = P.IdPortafoglio
                             WHERE T.IdTransazione = NEW.IdTransazione)
        WHERE IdPortafoglio = NEW.IdPortafoglio;
        RETURN NEW;
    END;
$$;

alter function triggeraggiornasaldoportafoglio() owner to postgres;

