create function triggerinizializzasaldoportafoglio() returns trigger
    language plpgsql
as
$$
    BEGIN
        UPDATE smu.Portafoglio
        SET Saldo = 0
        WHERE IdPortafoglio = NEW.IdPortafoglio;
        RETURN NEW;
    END;
$$;

alter function triggerinizializzasaldoportafoglio() owner to postgres;

