create function trigger2() returns trigger
    language plpgsql
as
$$
    BEGIN
        IF EXISTS(SELECT 1 FROM o.Accertamento_Effettuato AS AE JOIN o.Ricovero AS R ON
                                    AE.CodiceR = R.CodiceR WHERE AE.Esito IS NULL)
        THEN
            UPDATE o.Ricovero R SET DataF = NULL WHERE CodiceR = NEW.CodiceR;
            RAISE EXCEPTION 'Tutti gli accertamenti devono avere un esito';
        END IF;
        RETURN NEW;
    END;
    $$;

alter function trigger2() owner to postgres;

