create function trigger3() returns trigger
    language plpgsql
as
$$
    BEGIN
        IF EXISTS (SELECT * FROM o.Ricovero AS R WHERE R.CF = NEW.CF AND R.DataI = NEW.DataI AND R.DataF IS NULL) THEN
            IF EXISTS(SELECT *
                      FROM o.accertamento_effettuato AS AE JOIN o.Ricovero AS R ON AE.CodiceR = R.CodiceR
                      WHERE R.CF = NEW.CF AND R.DataI = NEW.DataI AND AE.Esito IS NULL AND AE.CodiceA IN(SELECT AE.CodiceA FROM o.accertamento_effettuato)) THEN
                          DELETE FROM o.Ricovero AS R WHERE R.CodiceR = NEW.CodiceR;
                RAISE EXCEPTION 'Non è possibile inserire un nuovo ricovero per il paziente % in data % in quanto non sono stati completati tutti gli esami del ricovero precedente', NEW.CF, NEW.DataI;
            END IF;

        END IF;
    RETURN NEW;
    END;
$$;

alter function trigger3() owner to postgres;

