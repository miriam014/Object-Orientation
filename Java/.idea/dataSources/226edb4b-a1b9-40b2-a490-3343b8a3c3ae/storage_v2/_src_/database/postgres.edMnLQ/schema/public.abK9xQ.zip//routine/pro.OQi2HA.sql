create function pro(string character varying) returns character varying
    language plpgsql
as
$$
    DECLARE
        numParoleSTR INTEGER;
        parolaSTR r.descrizione.parola%TYPE;
        numDOI INTEGER;
        cursDOI CURSOR FOR SELECT doi FROM r.articolo;
        currentDOI r.descrizione.doi%TYPE;
        match INTEGER;
        output VARCHAR(500);

    BEGIN
        string = replace(string, '+', '@'); -- sostituisce + con @
        numParoleSTR = regexp_count(string, '@') + 1; -- conta il numero di '@' nella stringa
        numDOI = (SELECT COUNT(doi) FROM r.articolo);

        OPEN cursDOI;

        FOR i IN 1..numDOI LOOP
            FETCH cursDOI INTO currentDOI;
            match = 0;
            FOR j in 1..numParoleSTR LOOP
                parolaSTR = split_part(string, '@', j);
                IF EXISTS (SELECT * FROM r.descrizione AS D
                                    WHERE d.doi = currentDOI AND d.parola = parolaSTR) THEN
                    match = match + 1;
                END IF;
                IF match = numParoleSTR THEN
                    output = concat(output, currentDOI);
                END IF;
            END LOOP;

        END LOOP;
        CLOSE cursDOI;

    RETURN output;
    END;
$$;

alter function pro(varchar) owner to postgres;

