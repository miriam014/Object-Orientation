create function crea_trigger1() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM p.Prenotazione AS PRE
    WHERE NEW.Utente = PRE.Utente;
    RETURN NEW;

END;
$$;

alter function crea_trigger1() owner to giuliagargiulo;

