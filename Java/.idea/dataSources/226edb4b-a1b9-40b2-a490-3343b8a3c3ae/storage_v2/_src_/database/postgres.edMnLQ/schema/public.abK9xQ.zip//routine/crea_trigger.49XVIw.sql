create function crea_trigger() returns trigger
    language plpgsql
as
$$
    BEGIN
        INSERT INTO a.Notifica
        SELECT
        FROM ((((a.Post Po NATURAL JOIN a.Presenza P) NATURAL JOIN a.Key K)
            JOIN a.Sottoscrizione S ON S.Tema=New.tema)
            JOIN a.Amici A ON New.IdUtente= IdUtente1)
        WHERE New.IdUtente<>S.IdUtente;
    END;

    $$;

alter function crea_trigger() owner to giuliagargiulo;

