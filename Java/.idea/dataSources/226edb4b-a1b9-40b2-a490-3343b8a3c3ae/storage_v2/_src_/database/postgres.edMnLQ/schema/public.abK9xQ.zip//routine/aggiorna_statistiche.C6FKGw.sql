create procedure aggiorna_statistiche()
    language plpgsql
as
$$
    DECLARE
        cursore REFCURSOR;
        CodF p.Utente.CF%TYPE;
        AnnoP INTEGER;
        numeroPrestiti p.statistiche.numprestiti%TYPE;
        numeroPrenotazioni p.statistiche.numpren%TYPE;

    BEGIN
        OPEN cursore FOR(
        SELECT U.CF as cf, extract(Year FROM (P.DataE)) AS anno, COUNT(*) AS NumPrestiti
        FROM p.Prestito AS P JOIN p.Utente AS U ON P.Utente = U.CF
        GROUP BY (P.Utente,extract(YEAR FROM (P.DataE)), U.CF));

        LOOP
        EXIT WHEN NOT FOUND;
        FETCH cursore INTO codF, annoP, numeroPrestiti;

        INSERT INTO p.statistiche(cf, anno, numprestiti)
            VALUES(codF, annoP, numeroPrestiti);
        END LOOP;
        CLOSE cursore;

        OPEN cursore FOR(
        SELECT U.CF as cf, extract(Year FROM (PR.Data)) As anno, COUNT(*) AS NumPrenotazioni
        FROM p.prenotazione AS PR JOIN p.Utente AS U ON PR.Utente = U.CF
        GROUP BY (PR.Utente,extract(YEAR FROM (PR.Data)), U.CF));

        LOOP
            EXIT WHEN NOT FOUND;
        FETCH cursore INTO codF, annoP, numeroPrenotazioni;

        UPDATE p.statistiche
        SET numPren = numeroPrenotazioni
        WHERE CF = codF AND anno = annoP;

        END LOOP;
        CLOSE cursore;

    END;
$$;

alter procedure aggiorna_statistiche() owner to giuliagargiulo;

