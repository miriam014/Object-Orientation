create function funzione3(stringa text) returns text
    language plpgsql
as
$$
DECLARE
    count          INTEGER := 0;
    localita       text;
    numCodici      INTEGER := regexp_count(stringa, '@') + 1;
    query          text    := 'SELECT P.CodPer FROM (l.Percorso AS P NATURAL JOIN l.Inpercorso AS I) JOIN ' ||
                              'l.Località AS L ON I.Nodo = L.CodNodo WHERE L.CodL = ';
    queryfinale    text;
    output         text;
    CodicePercorso INTEGER;
    cursore        refcursor;

BEGIN
    FOR i in 1..numCodici
        LOOP
            localita = split_part(stringa, '@', i);
            IF count = 0 THEN
                queryfinale := concat(query, localita);
            ELSE
                IF count < (numCodici - 1) THEN
                    queryfinale := concat(queryfinale, ' INTERSECT ', query, localita);
                ELSE
                    queryfinale := concat(queryfinale, ' INTERSECT ', query, localita, ';');
                END IF;
            END IF;

            count = count + 1;

        END LOOP;

    RAISE NOTICE 'Query: %', queryfinale;

    count = 0;
    OPEN cursore FOR EXECUTE queryfinale;
    LOOP

        FETCH cursore INTO CodicePercorso;
        EXIT WHEN NOT FOUND;
        IF count = 0 THEN
            output = CodicePercorso;
        ELSE
            output = concat(output, ',', CodicePercorso);
        END IF;

    END LOOP;
    CLOSE cursore;
    RETURN output;

END

$$;

alter function funzione3(text) owner to postgres;

