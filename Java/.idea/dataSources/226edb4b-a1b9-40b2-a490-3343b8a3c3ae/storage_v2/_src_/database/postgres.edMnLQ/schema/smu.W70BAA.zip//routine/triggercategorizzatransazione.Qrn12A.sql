create function triggercategorizzatransazione() returns trigger
    language plpgsql
as
$$
DECLARE
    nome_categoria smu.Categoria.NomeCategoria%TYPE;    --variabile per iterare sul nome categoria
    ArrayParoleChiavi TEXT[];            -- Array di testo per memorizzare le parole chiave di una categoria
    parola TEXT;                    -- Variabile per memorizzare temporaneamente ogni parola chiave
    matched BOOLEAN := FALSE;       -- Variabile booleana per indicare se è stata trovata una corrispondenza, inizializzata a false
BEGIN

    FOR nome_categoria IN
        SELECT NomeCategoria
        FROM smu.Categoria
    LOOP
        --la funzione string_to_array mi crea una stringa di valori a partire da una stringa di parole separate da virgole
        --successivamente memorizzo tale array in ArrayParoleChiavi
        SELECT string_to_array(ParoleChiavi, ',') INTO ArrayParoleChiavi
            FROM smu.Categoria
            WHERE NomeCategoria = nome_categoria;

        --memorizzo nella variabile parola l'elemento dell'array ParoleChiave
        FOREACH parola IN ARRAY ArrayParoleChiavi
        LOOP
            -- Verifica se la causale contiene la parola chiave
            IF NEW.Causale ILIKE '%' || parola || '%' THEN
                NEW.NomeCategoria := nome_categoria;
                matched := TRUE;
                EXIT;  -- Esce dal loop delle parole chiave una volta trovata una corrispondenza
            END IF;
        END LOOP;

        -- Se è stata trovata una corrispondenza interrompe il ciclo delle categorie
        IF matched THEN
            EXIT;
        END IF;

    END LOOP;

    -- Se nessuna categoria è stata trovata, assegno la transazione alla categoria "Altro"
    IF NOT matched THEN
       NEW.NomeCategoria := 'Altro';
    END IF;

    --aggiorno il nomecategoria della transazione
    UPDATE smu.Transazione
    SET NomeCategoria = NEW.NomeCategoria
    WHERE IdTransazione = NEW.IdTransazione;

    RETURN NEW;  -- Restituisce la nuova riga con il campo NomeCategoria aggiornato
    END;
$$;

alter function triggercategorizzatransazione() owner to postgres;

