create function aggiorna_descrizione() returns trigger
    language plpgsql
as
$$
    DECLARE
        parola_chiave refcursor;
    BEGIN
        FOR parola_chiave IN (SELECT P.Parola
                              FROM ((r.parolechiave AS P  NATURAL JOIN r.Rivista AS R) NATURAL JOIN r.Fascicolo AS F)
                                  NATURAL JOIN r.Articolo AS A WHERE NEW.DOI = A.Doi)
        LOOP
            IF(NEW.sommario NOT LIKE '%' || parola_chiave || '%') THEN
                INSERT INTO r.descrizione(parola, doi)
                VALUES(parola_chiave, NEW.doi);
            END IF;
        END LOOP;
        RETURN NEW;
    END;
$$;

alter function aggiorna_descrizione() owner to postgres;

