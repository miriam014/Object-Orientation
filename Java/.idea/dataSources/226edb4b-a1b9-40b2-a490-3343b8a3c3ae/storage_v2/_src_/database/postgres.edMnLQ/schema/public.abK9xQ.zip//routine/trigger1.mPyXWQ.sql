create function trigger1() returns trigger
    language plpgsql
as
$$
    BEGIN
        IF OLD.ordine = 0 THEN
            INSERT INTO l.INPERCORSO VALUES (OLD.CodPer, OLD.ordine, OLD.Nodo);
            RAISE EXCEPTION 'Impossibile cancellare il nodo iniziale';

        ELSE
            UPDATE l.INPERCORSO
            SET ordine = ordine - 1
            WHERE ordine >= OLD.ordine AND CodPer = OLD.CodPer;
        END IF;
        RETURN OLD;
    END;
$$;

alter function trigger1() owner to postgres;

