create function funzione2(stringa character varying) returns text
    language plpgsql
as
$$
    DECLARE
        parola1 VARCHAR(100);
        count INTEGER := 0;
        selectSTRING text := 'SELECT F.uri FROM f.Foto AS F NATURAL JOIN  f.Tagfoto AS T WHERE T.parola = ';
        query text;
        numParole INTEGER := regexp_count(stringa, '@') + 1;
        output text;
        currentUri varchar(10);
        cursor REFCURSOR;

    BEGIN
        FOR i IN 1..numParole LOOP
            parola1 = split_part(stringa, '@', i);
            IF count = 0 THEN
                query := concat(selectSTRING, '''', parola1, '''');
            ELSE
                IF count < numParole THEN
                query := concat(query, ' INTERSECT ', selectSTRING, '''', parola1, '''');
                ELSE
                query := concat(query, ' INTERSECT ', selectSTRING, '''', parola1, ''';');
                END IF;
            END IF;
            count = count + 1;
        END LOOP;
            RAISE NOTICE 'QUERY: {%}', query;

        OPEN cursor FOR EXECUTE query;
        count = 0;
        LOOP
            FETCH cursor INTO currentUri;
            EXIT WHEN NOT FOUND;
            IF count = 0 THEN
                output = currentUri;
            ELSE
                output = concat(output, '@', currentUri);
            END IF;
            count = count + 1;
        END LOOP;
        CLOSE cursor;
        RAISE NOTICE 'Risultato: {%}', output;
        RETURN output;
    END;

$$;

alter function funzione2(varchar) owner to postgres;

